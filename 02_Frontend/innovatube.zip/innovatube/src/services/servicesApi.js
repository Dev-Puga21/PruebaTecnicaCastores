/**
 * archivo pata
 */

// export const API_LOGIN = 'https://localhost:7186/api/login';
// export const API_REGISTER_USER = 'https://localhost:7186/api/RegisterUsers';

// export const API_ADD_FAVORITE = 'https://localhost:7186/api/videos/favorites';
// export const API_GET_FAVORITES = 'https://localhost:7186/api/videos/favorites';
// export const API_SEARCH_FAVORITES = 'https://localhost:7186/api/videos/favorites/search';
// export const API_REMOVE_FAVORITE = 'https://localhost:7186/api/videos/favorites';

//https://innovatube20250629202212.azurewebsites.net/

export const API_LOGIN = 'https://innovatube20250629202212.azurewebsites.net/api/login';
export const API_REGISTER_USER = 'https://innovatube20250629202212.azurewebsites.net/api/RegisterUsers';
export const API_FORGOT_PASSWORD = 'https://innovatube20250629202212.azurewebsites.net/api/forgot-password'
export const API_RESET_PASSWORD = 'https://innovatube20250629202212.azurewebsites.net/api/reset-password'

export const API_ADD_FAVORITE = 'https://innovatube20250629202212.azurewebsites.net/api/videos/favorites';
export const API_GET_FAVORITES = 'https://innovatube20250629202212.azurewebsites.net/api/videos/favorites';
export const API_SEARCH_FAVORITES = 'https://innovatube20250629202212.azurewebsites.net/api/videos/favorites/search';
export const API_REMOVE_FAVORITE = 'https://innovatube20250629202212.azurewebsites.net/api/videos/favorites';

export const API_KEY = 'AIzaSyBm0HZ1W1Yd7rt-DNMWOyUGjjUfV9YNL2Y'