import VideosComponent from '../components/Videos/VideosComponent'
import React from 'react'

const InicioPage = () => {
  return (
    <VideosComponent/>
  )
}

export default InicioPage
