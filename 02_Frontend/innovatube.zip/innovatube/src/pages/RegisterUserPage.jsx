import RegisterUserComponent from "../components/Security/Register/RegisterUserComponent"


const RegisterUserPage = () => {
  return (
      <RegisterUserComponent/>
  )
}

export default RegisterUserPage;