import LoginLogic from '../components/Security/Login/LoginLogicComponent'

import React from 'react'

const LoginPage = () => {
  return (
    <LoginLogic/>
  )
}

export default LoginPage