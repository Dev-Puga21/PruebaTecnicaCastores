import FavoriteVideos from '../components/Videos/FavoriteVideosComponent'
import React from 'react'

const FavoritesVideosPage = () => {
  return (
    <FavoriteVideos/>
  )
}

export default FavoritesVideosPage